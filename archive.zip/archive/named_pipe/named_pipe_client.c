#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include "../logarp/logarp.h"

//To store the logfile name
char logname[40] = "log.txt";

//define fifo
#define FIFO_NAME "/tmp/named_fifo"
const mode_t FIFO_MODE = 0660;

void *job(int number_sends, int last_send, int length_msg)
{
    //open pipe
    int fdread;
    if ((fdread = open(FIFO_NAME, O_RDONLY)) == -1)
    {
        log_entry(logname, "ERROR", __FILE__, __LINE__, "Could not open FIFO");
        fprintf(stderr, "Impossible to open the pipe: %s\n",
                strerror(errno));
        exit(EXIT_FAILURE);
    }

    //read all the messages
    char *full_array;
    if (NULL == (full_array = malloc(length_msg * number_sends + last_send)))
    {
        log_entry(logname, "ERROR", __FILE__, __LINE__, "malloc error on reading array");
    }
    char buffer[length_msg];
    char buffer_last[last_send];
    if (number_sends != 0)
    {
        for (int i = 0; i < number_sends; i++)
        {
            // lecture dans le tube
            if (read(fdread, buffer, length_msg) <= 0)
            {
                log_entry(logname, "ERROR", __FILE__, __LINE__, "reading error");
                exit(EXIT_FAILURE);
            }
            for (int j = 0; j < length_msg; j++)
            {
                full_array[i * length_msg + j] = buffer[j];
            }
        }
    }
    //read last message if it exists
    if (last_send != 0)
    {
        if (read(fdread, buffer_last, last_send) <= 0)
        {
            log_entry(logname, "ERROR", __FILE__, __LINE__, "reading error");
            exit(EXIT_FAILURE);
        }
        for (int j = 0; j < length_msg; j++)
        {
            full_array[number_sends * length_msg + j] = buffer_last[j];
        }
    }
    free(full_array);
    close(fdread);
    //remove fifo after reading
    int ret_value = remove(FIFO_NAME);
    if (ret_value != 0)
    {
        log_entry(logname, "ERROR", __FILE__, __LINE__, "Could not remove FIFO");
        printf("\nremove failed for %s", FIFO_NAME);
        printf("\nerrno is %d", errno);
        exit(EXIT_FAILURE);
    }
}

int main(int argc, char *argv[])
{
    //init logfile
    strncpy(logname, argv[2], 39);
    logname[39] = 0;
    log_entry(logname, "NOTICE", __FILE__, __LINE__, "Execution Started");

    //cut message into 10KB messages
    int LENGTH_MSG = atoi(argv[1]);
    int number_of_sends = 0;
    int last_send = LENGTH_MSG;
    if (LENGTH_MSG > 10000)
    {
        number_of_sends = LENGTH_MSG / 10000;
        last_send = LENGTH_MSG % 10000;
        LENGTH_MSG = 10000;
    }
    //read messages
    job(number_of_sends, last_send, LENGTH_MSG);
    log_entry(logname, "NOTICE", __FILE__, __LINE__, "Data read succesfully");
    return EXIT_SUCCESS;
}