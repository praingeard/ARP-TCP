#ifndef LOGARP
#define LOGARP
void log_entry(char *filename, char *nature, char *file, int line, char *msg );

#endif
